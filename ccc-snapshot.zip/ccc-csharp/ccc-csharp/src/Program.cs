﻿using System;
using System.Collections.Generic;

namespace CCC
{
    internal static class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}